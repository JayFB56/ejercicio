## Diseño de Direccionamiento
    Subneting / VLSM
    
## Configuración del Direccionamiento
    Interfaces Routers/Switch L3 (Core/Distribución)
    Interfaces Virtuales (VLAN) (Equipos de Distribución)
    Servicios DHCP [Core](Pendiente)/ Direccionamiento estático en terminales

## Configuración de Switching
    Enlaces troncales entre equipos de Acceso y Distribución
    Enlaces troncales entre equipos de Acceso 
    
## Enrutamiento




